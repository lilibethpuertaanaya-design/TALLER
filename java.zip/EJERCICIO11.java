/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author xioma
 */

import java.util.Scanner;

public class EJERCICIO11 { 
    public static void main (String[] args) {
    int n1,n2,su,re,mu,di;
    
   Scanner teclado=new Scanner (System.in);
   
        System.out.println("Digite el primer numero");n1=teclado.nextInt();
                System.out.println("Digite el segundo numero");n2=teclado.nextInt();
                
                su=n1+n2;
                re=n1-n2;
                mu=n1*n2;
                di=n1/n2;
                
                System.out.println("El resultado de la suma es:"+su);
                System.out.println("El resultado de la resta es:"+re);
                System.out.println("El resultado de la multiplicación es:"+mu);
                System.out.println("El resultado de la división es:"+di);
    }
}
