/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author xioma
 */
import java.util.Scanner;

public class EJERCICIO17 {
    public static void main (String[] args) {
    double a,b,area,p;
     
   Scanner teclado=new Scanner (System.in);
        System.out.println("Digite el primer lado del rectangulo:");a=teclado.nextDouble();
        System.out.println("Digite el segundo lado del rectangulo:");b=teclado.nextDouble();
        
        p=(2*a)+(2*b);
        area=a*b;
        
        System.out.println("El perimetro es:"+p);
         System.out.println("El area es:"+area);
    }
}
