/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller;

/**
 *
 * @author SENA
 */
import java.util.Scanner;
public class ejercicio16 {
      public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("radio:"); double r = sc.nextDouble();
          System.out.println("area:"+(Math. PI * r));
        
      }
}
        
       
