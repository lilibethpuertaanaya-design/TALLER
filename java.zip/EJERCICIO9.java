/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerdeejercicios;

/**
 *
 * @author Administrador
 */

import java.util.Scanner;

public class EJERCICIO9 {
    public static void main(String[] args) {
         double d,t,c,p;
         
          Scanner teclado=new Scanner(System.in);
          
          System.out.println("Digite el total de la compra");t=teclado.nextDouble();
          System.out.println("Digite el precio pagado");c=teclado.nextDouble();
          
          d=t-c;
          p=(d/t)*100;
          
          System.out.println("El porcentaje es:"+p+"%");
    }
}
