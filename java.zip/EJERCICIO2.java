/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerdeejercicios;

/**
 *
 * @author Administrador
 */
import java.util.Scanner;

public class EJERCICIO2 {
     public static void main(String[] args) {
        double vh;
        
        Scanner teclado=new Scanner (System.in);
        
        System.out.println("Si su salario es de 1.056.028 y su total de horas es 36");
         
         vh=1056028/36;
         
          System.out.println("El valor de su hora trabajada es:"+vh);
     }
}
