/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerdeejercicios;

/**
 *
 * @author Administrador
 */

import java.util.Scanner;
public class EJERCICIO10 {
    public static void main(String[] args) {
         double v,iv;
         
          Scanner teclado=new Scanner(System.in);
          
          System.out.println("Ingrese el valor del articulo");v=teclado.nextDouble();
          
          iv=v*0.19;
          System.out.println("El IVA de este articulo es:"+iv);
    }
}
