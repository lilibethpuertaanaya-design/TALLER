/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author xioma
 */

import java.util.Scanner;

public class EJERCICIO18 {
     public static void main (String[] args) {
     double l,a,p;
     
    Scanner teclado=new Scanner (System.in);
    
         System.out.println("Digite el lado del cuadrado:");l=teclado.nextDouble();
         
         p=4*l;
         a=l*2;
         
         System.out.println("El perimetro es:"+p);
         System.out.println("El area es:"+a);
    
     }
}
