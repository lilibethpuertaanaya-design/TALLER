/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author xioma
 */

import java.util.Scanner;

public class EJERCICIO5 {
     public static void main (String[] args) {
         double lado1,lado2,lado3,peri;
         
         Scanner teclado=new Scanner (System.in);
    
        System.out.println("Digite el primer lado");lado1=teclado.nextDouble();
             System.out.println("Digite el segundo lado");lado2=teclado.nextDouble();
            System.out.println("Digite el tercer lado");lado3=teclado.nextDouble();
            
            peri=lado1+lado2+lado3;
            
            System.out.println("El perimetro del triangulo es:"+peri);
     }
}
