/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tallerdeejercicios;

/**
 *
 * @author Administrador
 */

import java.util.Scanner;

public class EJERCICIO1 {

    public static void main(String[] args) {
        double vh,ht,st,ds,sn;
        
        Scanner teclado=new Scanner (System.in);
        
         System.out.println("Digite el numero de horas trabajadas");ht=teclado.nextDouble();
          System.out.println("Digite el valor por hora");vh=teclado.nextDouble();
          
          st=ht*vh;
          ds=st*0.05;
          sn=st-ds;
          
          System.out.println("El salario total es:"+st);
          System.out.println("El 5% como retención es:"+ds);
           System.out.println("El salario neto es:"+sn);
       
    }
}
