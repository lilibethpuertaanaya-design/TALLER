/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author xioma
 */

import java.util.Scanner;

public class EJERCICIO3 {
      public static void main (String[] args) {
     double n1,n2,n3,n,p;
     
    Scanner teclado=new Scanner (System.in);
    
          System.out.println("Ingrese la primera nota:");n1=teclado.nextDouble();
           System.out.println("Ingrese la segunda nota:");n2=teclado.nextDouble();
           
           n=(n1*0.20)+(n2*0.20);
           n3=(3.0-n)/0.60;
     
            System.out.println("La nota minima que debe sacar en el tercer corte es: " + n3);
        
           }
      }
