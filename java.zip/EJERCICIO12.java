/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerdeejercicios;

/**
 *
 * @author Administrador
 */

import java.util.Scanner;

public class EJERCICIO12 {
      public static void main(String[] args) {
         int cif,n;
         
         Scanner teclado=new Scanner(System.in);
         
          System.out.println("Ingrese el numero");n=teclado.nextInt();
          cif=n%10;
          System.out.println("El ultimo numero es:"+cif);
      }
}
