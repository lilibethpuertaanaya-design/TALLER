/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerdeejercicios;

/**
 *
 * @author Administrador
 */

 import java.util.Scanner;

public class EJERCICIO131 {
     public static void main(String[] args) {
         double ce,pu;
         
          Scanner teclado=new Scanner(System.in);
           System.out.println("Digite los centimetros");ce=teclado.nextDouble();
           
           pu=ce*2.54;
           
           System.out.println("Las pulgadas son:"+pu);
           
           
     }
}

