/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taller;

/**
 *
 * @author SENA
 */
import java.util.Scanner;
public class ejercicio14 {
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("tiempo en segundos:"); int total = sc.nextInt();
        int horas= total / 3600;
        int minutos= (total % 3600) / 60;
        int segundos= total % 60;
        System.out.println(horas+"horas,"+minutos+"minutos,"+segundos+"segundos");
        
    }
    
}
