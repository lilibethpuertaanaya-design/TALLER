/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author xioma
 */

import java.util.Scanner;
        
public class EJERCICIO4 {
    public static void main (String[] args) {
    double area,base,altura;
    
    Scanner teclado=new Scanner (System.in);
    
        System.out.println("Digite la base");base=teclado.nextDouble();
             System.out.println("Digite la altura");altura=teclado.nextDouble();  
             
             area=base*altura;
             
             System.out.println("El area es:"+area);
            }   
}
