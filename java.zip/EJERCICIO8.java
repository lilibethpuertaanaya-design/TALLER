/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerdeejercicios;

/**
 *
 * @author Administrador
 */

import java.util.Scanner;

public class EJERCICIO8 {
     public static void main(String[] args) {
         double m,mll;
         
          Scanner teclado=new Scanner(System.in);
          
          System.out.println("Digite la cantidad de millas marinas");mll=teclado.nextDouble();
          
          m=mll*1852;
          
            System.out.println("La distancia expresada en metros es:"+m);
     }
}
     
