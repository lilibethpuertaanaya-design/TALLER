/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author xioma
 */
import java.util.Scanner;

public class EJERCICIO6 {
      public static void main (String[] args) {
          double c,fah;
          
          Scanner teclado=new Scanner (System.in);
          
           System.out.println("Digite los grados celsius");c=teclado.nextDouble();
           
          fah=(c*1.8)+32;
          
           System.out.println("Los grados fahrenheit son:"+fah);
          
          
      }
}
